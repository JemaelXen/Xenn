module.exports = {
  secret: 'supersecretkey',
  database: 'mongodb://localhost:27017/ariesco'
};