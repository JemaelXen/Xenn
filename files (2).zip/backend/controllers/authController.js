const jwt = require('jsonwebtoken');
const User = require('../models/User');
const config = require('../config');

exports.register = (req, res) => {
  const newUser = new User(req.body);
  newUser.save((err, user) => {
    if (err) return res.status(400).send({ msg: 'Error registering user', error: err });
    user.password = undefined;
    res.status(201).send(user);
  });
};

exports.login = (req, res) => {
  User.findOne({ email: req.body.email }, (err, user) => {
    if (err) return res.status(400).send({ msg: 'Error finding user', error: err });
    if (!user) return res.status(404).send({ msg: 'User not found' });

    user.comparePassword(req.body.password, (err, isMatch) => {
      if (err) return res.status(400).send({ msg: 'Error comparing password', error: err });
      if (!isMatch) return res.status(401).send({ msg: 'Invalid password' });

      const token = jwt.sign({ id: user._id, role: user.role }, config.secret, { expiresIn: '1h' });
      res.status(200).send({ token });
    });
  });
};