import React from 'react';

function LandingPage() {
  return (
    <div>
      <header className="hero">
        <img src="/logo.webp" alt="Aries & Co Logo" className="logo" />
        <h1>Welcome to Aries & Co</h1>
        <p>Your Secure, Global Banking Experience</p>
        <button>Get Started</button>
      </header>
      <section className="features">
        <h2>Key Features</h2>
        <div className="feature">
          <h3>Global Transactions</h3>
          <p>Seamless international transactions with competitive rates.</p>
        </div>
        <div className="feature">
          <h3>QR Code Payments</h3>
          <p>Convenient payments with QR codes.</p>
        </div>
        <div className="feature">
          <h3>AI-Driven Security</h3>
          <p>Advanced security with AI-driven fraud detection.</p>
        </div>
        <div className="feature">
          <h3>Investment Options</h3>
          <p>Diverse investment options for your financial growth.</p>
        </div>
      </section>
      <section className="testimonials">
        <h2>User Testimonials</h2>
        <div className="testimonial">
          <p>"Aries & Co has transformed my banking experience!" - User A</p>
        </div>
        <div className="testimonial">
          <p>"Highly secure and easy to use." - User B</p>
        </div>
      </section>
      <footer>
        <button>Sign Up</button>
        <button>Login</button>
      </footer>
    </div>
  );
}

export default LandingPage;