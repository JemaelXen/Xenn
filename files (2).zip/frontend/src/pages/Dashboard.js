import React from 'react';

function Dashboard() {
  return (
    <div>
      <header className="dashboard-header">
        <h1>Dashboard</h1>
        <nav>
          <ul>
            <li><a href="/dashboard">Home</a></li>
            <li><a href="/transactions">Transactions</a></li>
            <li><a href="/cards">Credit/Debit Cards</a></li>
            <li><a href="/investments">Investments</a></li>
            <li><a href="/global-transactions">Global Transactions</a></li>
            <li><a href="/security-settings">Security Settings</a></li>
            <li><a href="/support">Customer Support</a></li>
          </ul>
        </nav>
      </header>
      <main>
        <section className="summary-widget">
          <h2>Account Summary</h2>
          <p>Balance: $00.00</p>
          <p>Recent Transactions: </p>
          {/* List recent transactions here */}
        </section>
        <section className="alerts-notifications">
          <h2>Alerts & Notifications</h2>
          <p>No new alerts</p>
        </section>
        <section className="global-transactions">
          <h2>Global Transactions & Conversion Rates</h2>
          <p>Exchange Rate: 1 USD = 0.85 EUR</p>
          {/* Real-time conversion rates */}
        </section>
        <section className="investment-overview">
          <h2>Investment Overview</h2>
          <p>No active investments</p>
        </section>
      </main>
    </div>
  );
}

export default Dashboard;